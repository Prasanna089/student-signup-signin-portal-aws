# GitHub upload formats

| Content | Recommended format |
|---|---|
| AWS Lambda source | `.py` |
| Frontend | `.html` (single-file frontend) |
| Architecture diagram | `.png` or `.jpg` |
| Screenshots | `.png` or `.jpg` |
| Documentation | `.pdf` or `.md` |
| IAM policy template | `.json` |
| Lambda test events | `.json` |
| Project package for local backup | `.zip` |

Use descriptive filenames, for example `lambda-function-overview.png`, `api-gateway-routes.png`, `signup-success.png`, and `signin-success.png`. Redact account identifiers, email addresses, passwords, tokens, and any other sensitive data before publishing.
